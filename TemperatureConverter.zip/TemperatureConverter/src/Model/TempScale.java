package Model;

public enum TempScale {
  CELSIUS,
  FAHRENHEIT,
  KELVIN
}
